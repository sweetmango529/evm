enum ButtonStatus {
  active,
  inactive,
  disabled,
}

export default ButtonStatus;
